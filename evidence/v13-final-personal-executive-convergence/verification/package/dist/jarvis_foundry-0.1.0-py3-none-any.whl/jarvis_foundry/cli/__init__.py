"""Local JARVIS controls."""

