"""Deterministic briefing-item projection from the append-only event ledger.

The item model is intentionally read-only.  It gives every owner-facing
briefing line a stable source event, dedupe identity, entity link, freshness,
and explicit owner-action classification without making a mutable UI table an
authority.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable

from .database import FoundryDatabase
from .events import Event, payload_hash

ITEM_VERSION = "1.1"
DEFAULT_ITEM_LIMIT = 50

_SKIP_EVENT_TYPES = frozenset({
    "owner_control.nonce_used",
    "briefing.planned",
    "briefing.claimed",
    "briefing.delivered",
    "briefing.failed",
    "supervisor.heartbeat",
    # A verifier PASS is preliminary until AcceptanceGate records its
    # immutable acceptance receipt below.
    "verification.passed",
})


@dataclass(frozen=True, slots=True)
class BriefingItem:
    item_id: str
    dedupe_key: str
    item_version: str
    category: str
    importance: int
    freshness: str
    entity_kind: str | None
    entity_id: str | None
    mission_id: str | None
    source_event_id: str
    source_event_type: str
    source_sequence: int
    occurred_at: str
    summary: str
    owner_action_required: str
    evidence_refs: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "dedupe_key": self.dedupe_key,
            "item_version": self.item_version,
            "category": self.category,
            "importance": self.importance,
            "freshness": self.freshness,
            "entity_kind": self.entity_kind,
            "entity_id": self.entity_id,
            "mission_id": self.mission_id,
            "source_event_id": self.source_event_id,
            "source_event_type": self.source_event_type,
            "source_sequence": self.source_sequence,
            "occurred_at": self.occurred_at,
            "summary": self.summary,
            "owner_action_required": self.owner_action_required,
            "evidence_refs": list(self.evidence_refs),
            "metadata": dict(self.metadata),
        }


def _now(value: datetime | str | None) -> datetime:
    if value is None:
        return datetime.now(timezone.utc)
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError, OverflowError):
        # A malformed fake clock must not crash a restart/replay.  Keep the
        # resulting freshness explicitly UNKNOWN rather than inventing a
        # current timestamp.
        return datetime.min.replace(tzinfo=timezone.utc)
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _freshness(occurred_at: str, now: datetime) -> str:
    if now.year == datetime.min.year:
        return "UNKNOWN"
    try:
        occurred = datetime.fromisoformat(str(occurred_at).replace("Z", "+00:00"))
        if occurred.tzinfo is None:
            occurred = occurred.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError, OverflowError):
        return "UNKNOWN"
    if occurred > now:
        return "FUTURE"
    age_days = max(0.0, (now - occurred).total_seconds() / 86400.0)
    return "FRESH" if age_days <= 2.0 else "LATE"


def _text(value: Any, *, limit: int = 320) -> str:
    if value is None:
        return ""
    raw = str(value).replace("\x00", " ").strip()
    return raw if len(raw) <= limit else raw[: limit - 1] + "…"


def _payload_summary(event: Event) -> str:
    payload = event.payload if isinstance(event.payload, dict) else {}
    if event.event_type == "mission.outcome_finalized":
        briefing = payload.get("briefing")
        if isinstance(briefing, dict):
            attempted = _text(briefing.get("what_was_attempted"), limit=180)
            result = _text(briefing.get("result"), limit=40)
            if attempted and result:
                return f"{attempted} -> {result}"
    for key in (
        "reason", "exact_text", "objective", "summary", "error",
        "failure_class", "next_action", "status", "question",
    ):
        value = _text(payload.get(key))
        if value:
            return value
    try:
        return _text(json.dumps(payload, sort_keys=True, ensure_ascii=True))
    except (TypeError, ValueError):
        return "event payload is not serializable"


def _entity(event: Event) -> tuple[str | None, str | None, str | None]:
    payload = event.payload if isinstance(event.payload, dict) else {}
    if str(event.event_type or "").startswith("chief_of_staff."):
        project_id = payload.get("project_id")
        if isinstance(project_id, str) and project_id.strip():
            mission_id = payload.get("mission_id")
            return (
                "project",
                project_id.strip(),
                mission_id if isinstance(mission_id, str) else None,
            )
    for key, kind in (
        ("mission_id", "mission"),
        ("decision_id", "decision"),
        ("directive_id", "directive"),
        ("candidate_id", "candidate"),
        ("run_id", "agent_run"),
        ("effect_ticket_id", "effect"),
        ("lineage_id", "lineage"),
        ("action_key", "effect"),
        ("connector_request_id", "connector_request"),
        ("resource_id", "resource"),
        ("question_id", "question"),
    ):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            mission_id = payload.get("mission_id")
            return kind, value.strip(), mission_id if isinstance(mission_id, str) else None
    return None, None, None


def _rule(event: Event) -> tuple[str, int, str]:
    event_type = str(event.event_type or "")
    payload = event.payload if isinstance(event.payload, dict) else {}
    if event_type == "chief_of_staff.owner_attention_required":
        return "PROJECT", 5, "DECISION_REQUIRED"
    if event_type.startswith("chief_of_staff."):
        if event_type == "chief_of_staff.candidate_routed":
            return "PROJECT", 3, "INFORM"
        if event_type == "chief_of_staff.recommendation_rejected":
            return "PROJECT", 2, "INFORM"
        if event_type == "chief_of_staff.wait_recorded":
            return "PROJECT", 2, "INFORM"
        return "PROJECT", 2, "INFORM"
    if event_type in {"owner_directive.recorded", "owner_directive.revoked", "owner_directive.superseded"}:
        command = str(payload.get("command_type") or "")
        if command in {"STOP_EVERYTHING", "PAUSE", "VETO_ACTION", "STOP_MISSION"}:
            return "OWNER_CONTROL", 5, "OWNER_VETO_ACTIVE"
        if event_type != "owner_directive.recorded":
            return "OWNER_CONTROL", 4, "INFORM"
        return "OWNER_CONTROL", 4, "DECISION_REQUIRED"
    if event_type in {"executive.materialization_blocked", "mission.blocked", "mission.blocked_recorded"}:
        return "BLOCKER", 5, "BLOCKED_EXTERNAL_DEPENDENCY"
    if event_type in {"supervisor.degraded", "worker.failed", "agent_run.failed", "mission.failed"}:
        return "EXCEPTION", 5, "DECISION_REQUIRED"
    if event_type == "executive.decision_recorded":
        decision = str(payload.get("decision") or "")
        return "DECISION", 4 if decision in {"SELECT", "REJECT", "DEFER"} else 3, "INFORM"
    if event_type.startswith("knowledge.") or event_type.startswith("memory."):
        return "KNOWLEDGE", 2, "INFORM"
    if event_type in {"resource.usage_recorded", "provider.usage_recorded"}:
        return "COST", 3, "INFORM"
    if event_type == "verification.accepted":
        return "VERIFICATION", 4, "INFORM"
    if event_type == "mission.outcome_finalized":
        return "OUTCOME", 4, "INFORM"
    # V5 effect truth is useful to an owner only after it is reduced to the
    # durable attempt/lineage state.  Raw provider content never changes the
    # category or authority of an item.
    if event_type in {
        "connector.attempt_recorded", "correlation.lineage_recorded",
        "system.action_started", "system.action_completed",
        "system.action_failed", "effect.frozen", "effect.reconcile_mismatch",
    }:
        outcome = str(payload.get("outcome") or payload.get("status") or "").upper()
        if event_type in {"system.action_failed", "effect.frozen",
                          "effect.reconcile_mismatch"} or outcome in {
            "FAILED", "UNKNOWN", "FROZEN", "BLOCKED",
        }:
            return "EFFECT", 5, "DECISION_REQUIRED"
        if outcome in {"COMPLETED", "COMPENSATED", "CANCELLED"} or \
                event_type == "system.action_completed":
            return "EFFECT", 3, "INFORM"
        return "EFFECT", 3, "UNKNOWN"
    # V6 records are evidence-backed evolution signals.  They may explain a
    # candidate or a gate to the owner, but they cannot grant authority merely
    # by appearing in the briefing stream.
    if event_type.startswith((
        "improvement.", "hypothesis.", "measurement.", "experiment.",
        "candidate.", "shadow.", "benchmark.", "verifier.",
        "eligibility.", "cycle.", "feedback.", "evolution.",
    )):
        decision = str(payload.get("decision") or payload.get("verdict") or
                       payload.get("outcome") or payload.get("status") or "").upper()
        if decision in {"FAIL", "FAILED", "REJECTED", "BLOCKED",
                        "UNKNOWN", "ROLLED_BACK", "NOT_TESTED"} or \
                payload.get("trusted_independent_pass") is False or \
                event_type.endswith(("_failed", ".failed", "_rejected",
                                     ".rejected", ".blocked", ".rolled_back")):
            return "EVOLUTION", 5, "DECISION_REQUIRED"
        if decision in {"PASS", "PROMOTED", "COMPLETED", "ELIGIBLE",
                        "CONFIRMED", "PARTIAL"} or \
                payload.get("trusted_independent_pass") is True:
            return "EVOLUTION", 3, "INFORM"
        return "EVOLUTION", 3, "UNKNOWN"
    if event_type.startswith("mission.") or event_type.startswith("agent_run."):
        return "MISSION", 3, "INFORM"
    if event_type.startswith("release.") or event_type.startswith("rollback."):
        return "RELEASE", 4, "INFORM"
    if event_type.startswith("portfolio.") or event_type.startswith("discovery."):
        return "DISCOVERY", 2, "INFORM"
    return "EVENT", 1, "UNKNOWN"


def _evidence_refs(event: Event) -> tuple[str, ...]:
    payload = event.payload if isinstance(event.payload, dict) else {}
    refs: list[str] = [event.event_id]
    for key in (
        "evidence_ref", "evidence_id", "last_event_id", "verdict_id",
        "attempt_id", "effect_ticket_id", "lineage_id",
        "connector_request_id",
    ):
        value = payload.get(key)
        if isinstance(value, str) and value and value not in refs:
            refs.append(value)
    raw = payload.get("evidence_refs")
    if isinstance(raw, list):
        for value in raw:
            if isinstance(value, str) and value and value not in refs:
                refs.append(value)
    source_refs = payload.get("source_event_refs")
    if isinstance(source_refs, list):
        for value in source_refs:
            if isinstance(value, str) and value and value not in refs:
                refs.append(value)
    return tuple(refs[:12])


def event_to_item(event: Event, sequence: int, *, now: datetime | str | None = None) -> BriefingItem | None:
    """Convert one authoritative event to a bounded item, or skip noise."""
    event_type = str(event.event_type or "")
    if event_type in _SKIP_EVENT_TYPES:
        return None
    category, importance, action = _rule(event)
    entity_kind, entity_id, mission_id = _entity(event)
    payload = event.payload if isinstance(event.payload, dict) else {}
    target = _text(payload.get("target"))
    dedupe_key = f"{event_type}:{event.event_id}"
    item_id = f"brief-item-{payload_hash({'event_id': event.event_id, 'event_type': event_type})[:24]}"
    metadata = {
        "source_type": event.source_type,
        "source_id": event.source_id,
        "correlation_id": event.correlation_id,
        "causation_id": event.causation_id,
    }
    if target:
        metadata["target"] = target
    return BriefingItem(
        item_id=item_id,
        dedupe_key=dedupe_key,
        item_version=ITEM_VERSION,
        category=category,
        importance=importance,
        freshness=_freshness(event.occurred_at, _now(now)),
        entity_kind=entity_kind,
        entity_id=entity_id,
        mission_id=mission_id,
        source_event_id=event.event_id,
        source_event_type=event_type,
        source_sequence=sequence,
        occurred_at=event.occurred_at,
        summary=_payload_summary(event),
        owner_action_required=action,
        evidence_refs=_evidence_refs(event),
        metadata=metadata,
    )


def project_briefing_items(
    database: FoundryDatabase,
    *,
    after_sequence: int = 0,
    now: datetime | str | None = None,
    limit: int = DEFAULT_ITEM_LIMIT,
    max_scan: int | None = None,
) -> list[BriefingItem]:
    """Project deterministic items after a ledger cursor in ledger order."""
    items: list[BriefingItem] = []
    events = database.events(
        readonly=True,
        limit=max_scan,
        newest_first=max_scan is not None,
    )
    if max_scan is not None:
        head = database.event_count(readonly=True)
        events = list(reversed(events))
        start = max(1, head - len(events) + 1)
    else:
        start = 1
    for sequence, event in enumerate(events, start=start):
        if sequence <= max(0, int(after_sequence)):
            continue
        item = event_to_item(event, sequence, now=now)
        if item is not None:
            items.append(item)
    # Priority is a presentation decision; source sequence remains the stable
    # cursor and is retained in each item for replay/debugging.
    items.sort(key=lambda item: (-item.importance, item.source_sequence, item.item_id))
    return items[: max(1, int(limit))]


def exception_item(item: BriefingItem) -> bool:
    return item.owner_action_required != "INFORM" or item.importance >= 4


def briefing_item_keys(items: Iterable[dict[str, Any] | BriefingItem]) -> set[str]:
    keys: set[str] = set()
    for item in items:
        value = item.to_dict() if isinstance(item, BriefingItem) else item
        key = value.get("dedupe_key") if isinstance(value, dict) else None
        if isinstance(key, str) and key:
            keys.add(key)
    return keys
